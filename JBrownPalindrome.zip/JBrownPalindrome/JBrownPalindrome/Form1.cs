namespace JBrownPalindrome
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label2.Visible = true;
            string name = "";
            name = CleanUp(ref name);
            string test = "";

            int x = name.Length - 1;
            while (test.Length < name.Length)
            {
                test = test + name.Substring(x, 1);
                x--;
            }
            CheckIt(name, test);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Visible = false;
            label2.Visible = false;
        }
        private void CheckIt(string old, string check)
        {
            string name1 = old.ToLower();
            string name2 = check.ToLower();
            if (name1 == name2)
            {
                label2.Text = "It's a palindrome!";
            }
            else
            {
                label2.Text = "It is not a palindrome :(";
            }
        }

        private string CleanUp(ref string clean)
        {
            int i = 0;
            while (i < textBox1.TextLength)
            {
                if (textBox1.Text.Substring(i, 1) != " ")
                {
                    clean += textBox1.Text.Substring(i, 1);
                    i++;
                }
                else
                {
                    i++;
                }
            }
            return clean;
        }
    }
}